let anoNascimento = 0;
anoNascimento = parseInt(prompt("Em qual ano você nasceu?"));
let idade = 2023 - anoNascimento;

if (idade >= 16) {
    let titulo = parseInt(prompt('Você possui título?\n1 - Sim\n2 - Não'));
    if (titulo == 1) {
        alert('Você tem ' + idade + ' anos de idade e pode votar!');
    }
}
else if (idade >= 16 && titulo == 2) {
    alert('Você tem ' + idade + ' anos de idade e precisa fazer o seu título para poder votar!');
}
else {
    alert('Você tem ' + idade + ' anos de idade e não pode votar!');
}