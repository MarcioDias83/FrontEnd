let friends = ["José", "Maria", "Pedro" , "Ana", 1];
console.log(friends[1]);
friends[1] = "Joana";
console.log(friends[1]);
friends[5] = "Pedro";
console.log(friends);
