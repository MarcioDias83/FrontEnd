let firstName = prompt('Qual é o seu primeiro nome?');
let lastName = prompt('Qual é o seu último nome?');
let age = parseInt(prompt('Qual é a sua idade?'));
const age2 = 2;

age = age + age2;

console.log('Meu nome é ' + firstName + " " + lastName + ' e tenho ' + age + ' anos.');
