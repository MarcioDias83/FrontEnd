let celsius = 0
let fahrenheit = 0

celsius = prompt("Digite a temperatura em Celsius: ");
fahrenheit = (celsius * 9/5) + 32;
alert("A temperatura em Fahrenheit é: " + fahrenheit);
