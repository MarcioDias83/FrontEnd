let firstName = "Marcio";
let lastName = "Dias";
let age = 39;
console.log('Meu nome é ' + firstName + " " + lastName + ' e tenho ' + age + ' anos.');