// conta com decimal
//  gorjeta com decimal
// total com decimal
let conta = parseFloat(prompt("Qual o valor da conta?"));
let gorjeta = parseFloat(prompt("Qual o valor da gorjeta?"));
let total = (conta * gorjeta) / 100;
alert("O valor total da conta é de R$" + total + '.');