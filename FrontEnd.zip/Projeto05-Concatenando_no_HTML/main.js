let firstName = prompt('Qual é o seu primeiro nome?');
let greeting = 'Olá, ';
document.getElementById('greeting').innerHTML = greeting + ' ' + firstName + '!';
