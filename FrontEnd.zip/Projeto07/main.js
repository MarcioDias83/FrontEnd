let celsius = prompt("Digite a temperatura em Celsius: ");
let fahrenheit = (celsius * 9/5) + 32;
alert("A temperatura em Fahrenheit é: " + fahrenheit);
