let nota = parseInt(prompt("Digite a nota: "));

if (nota >= 90 && nota <= 100) {
    alert("Nota A");
} else if (nota >= 80 && nota <= 89) {
    alert("Nota B");
} else if (nota >= 70 && nota <= 79) {
    alert("Nota C");
} else if (nota >= 60 && nota <= 69) {
    alert("Nota D");
} else if (nota >= 0 && nota <= 59) {
    alert("Nota F");
} else {
    alert("Nota inválida!");
}
